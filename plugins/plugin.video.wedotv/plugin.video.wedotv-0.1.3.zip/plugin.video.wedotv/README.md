# plugin.video.wedotv

A plugin that get's content from WeDoTV.
WeDoTV was peviously branded W4Free and is a free VOD service in the UK and Germany.

## Install
This plugin can be installed from the AzzyAddons repo: https://azzyaddons.github.io
