# -*- coding: utf-8 -*-
from __future__ import absolute_import

from lib import plugin

plugin.run()