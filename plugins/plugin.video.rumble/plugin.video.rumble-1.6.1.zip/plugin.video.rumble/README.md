Ilikenwf forked this from https://github.com/OnePlayHD/OneRepo as they had the GPL in their repo, but for whatever reason had the code for this addon obfuscated.

The code has been unobfuscated and cleaned up.<br />
Also has been updated for the new rumble site layout and is now both python 2 & 3 compatible.<br />

Users can now login to see their subscription feed.<br />
To login go to "Settings" -> "Login"<br />
Then enter your username & password.<br />
Save the settings.<br />

<b>Subscription functionality</b><br />
- See your feeds from subscriptions<br />
- See your followed channels & users<br />
- Subscribe to channel & users<br />
- Unsubscribe to channels & users<br />
- View video comments<br />
<br />
<b>Issues</b><br />
If an issue occurs where the stream freezes after start,<br />
you can try to enable http streams:<br />
- Go to settings<br />
- Debug<br />
- Use HTTP
