Ilikenwf forked this from https://github.com/OnePlayHD/OneRepo as they had the GPL in their repo, but for whatever reason had the code for this addon obfuscated.

The code has been unobfuscated and cleaned up.<br />
Also has been updated for the new rumble site layout and is now both python 2 & 3 compatible.<br />

Users can now login to see their subscription feed.<br />
To login go to "Settings" -> "Login"<br />
Then enter your username & password.<br />
Save the settings.<br />

## Subscription functionality
- See your feeds from subscriptions<br />
- See your followed channels & users<br />
- Subscribe to channel & users<br />
- Unsubscribe to channels & users<br />
- View your "Watch later" playlist<br />
- Add videos to your "Watch later" playlist<br />
- Delte videos from your "Watch later" playlist<br />
- View video comments<br />

## Install
This plugin can be installed from the AzzyAddons repo: https://azzyaddons.github.io

## Issues
All though the plugin tries it best to get around the Cloudflare Protection of the site,<br />
there are times it may be unable to bypass the verification.<br />
If this is the case, the only way around it is to use a cloudflare bypass tool such as Flaresolverr or Byparr.

You will need to setup Flaresolverr or Byparr (Guides can be found online).

To enable Flaresolverr / Byparr integration:
- Go to the plugin settings<br />
- Cloudflare Bypass<br />
- Enabled
- Enter Flaresolverr / Byparr Details
